<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="styles.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>

<h3 align="center"> Update Profile</h3>

<div class="container">
  <form action="/action_page.php">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="email">Email</label>
    <input type="text" id="email" name="email" placeholder="Your email..">


    <label for="campus">Campus</label>
    <select id="campus" name="campus">
      <option value="boca raton">Boca Raton</option>
      <option value="davie">Davie</option>
      <option value="fort lauderdale">Fort Lauderdale</option>
      <option value="dania beach">Dania Beach</option>
      <option value="jupiter">Jupiter</option>
      <option value="harbor branch">Harbor Branch</option>
    </select>

    <label for="major">Major</label>
    <select id="major" name="major">
      <option value="computer engineering">Computer Engineering</option>
      <option value="computer science">Computer Science</option>
    </select>

    <label for="bio">Bio</label>
    <textarea id="bio" name="bio" placeholder="Share something about yourself..." style="height:200px"></textarea>

    <input type="submit" value="Submit">
  </form>
</div>

</body>
</html>
