<!DOCTYPE html>
<html>
<head>
  <title>Home</title>
<meta charset="UTF-8" name="" content="">
<link rel="stylesheet" href="styles4.css">
</head>
<body>
  <div id="info_box">
    <p1 id="text_info"></p>
    <img id="prof_pic" src="" alt="">
  </div>
</body>
</html>
