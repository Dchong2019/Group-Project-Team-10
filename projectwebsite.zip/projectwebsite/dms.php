<!DOCTYPE html>
<html>
<head>
  <title>Home</title>
<meta charset="UTF-8" name="" content="">
<link rel="stylesheet" href="styles5.css">
</head>
<body>
  <div id="chat_box">
    <p1 id="display"></p1>
    <p2 id="text_box"></p2>
    <p3 id="send">Send</p3>
  </div>
</body>
</html>
