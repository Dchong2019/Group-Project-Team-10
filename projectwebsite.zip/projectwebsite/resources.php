<!DOCTYPE html>
<html>
<head>
  <title>Home</title>
<meta charset="UTF-8" name="" content="">
<link rel="stylesheet" href="styles7.css">
</head>
<body>
  <h1>What programming language should I learn?</h1>
  <div id="first_box">
    <p1>The Answer to that question depends on what your career goals are:</p1>
      <img src="images/recommendations.jpg" alt="Recommendations">
  </div>
  <h1>Programming Language Resources</h1>
  <div id="second_box">
    <div id="python">
      <h2>Python</h2>
      <a href="https://www.youtube.com/results?search_query=python+for+beginners">Learn Python from Youtube</a>
      <a href="https://www.w3schools.com/python/">Learn Python from W3Schools</a>
    </div>
    <div id="csharp">
      <h2>C# (C-Sharp)</h2>
      <a href="https://www.youtube.com/results?search_query=c%23+for+beginners">Learn C# by Youtube</a>
      <a href="https://www.w3schools.com/cs/">Learn C# by W3Schools</a>
    </div>
  </div>
</body>
</html>
