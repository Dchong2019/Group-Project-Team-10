<!DOCTYPE html>
<html>
<head>
  <title>Home</title>
<meta charset="UTF-8" name="" content="">
<link rel="stylesheet" href="styles6.css">
</head>
<body>
  <div id="major_select">
    <h1 id="major_title">Majors</h1>
    <p1 id="text_box"></p1>
    <p2 id="search">Search</p2>
  </div>
  <div id="major_select_list">
    <img id="cs_select_image" src="" alt="">
    <p2 id="cs_select">Computer Science</p2>
    <img id="ce_select_image" src="" alt="">
    <p2 id="ce_select">Computer Engineering</p2>
    <p3 id="logout">Logout</p3>
    <p4 id="return">Back to Main Page</p4>
  </div>

</body>
</html>
