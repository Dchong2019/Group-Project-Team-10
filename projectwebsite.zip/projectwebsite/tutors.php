<!DOCTYPE html>
<html>
<head>
  <title>Home</title>
<meta charset="UTF-8" name="" content="">
<link rel="stylesheet" href="styles1.css">
</head>
<body>
  <h1>Tutors</h1>
  <img src="" alt="">
  <ul>
    <li id="name">Name</li>
    <li id="major">Major</li>
    <li id="email">Email</li>
    <li id="availability">Availability</li>
    <li id="zoom">Zoom Room</li>
  </ul>
</body>
</html>
