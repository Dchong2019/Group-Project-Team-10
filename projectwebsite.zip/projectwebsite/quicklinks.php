<!DOCTYPE html>
<html>
<head>
  <title>Home</title>
<meta charset="UTF-8" name="" content="">
<link rel="stylesheet" href="styles2.css">
</head>
<body>
  <div id="outer_box">
    <h1>Quick Links</h1>
    <ul>
    <a href="https://sso.fau.edu/idp/profile/SAML2/Redirect/SSO?execution=e2s1">  <img src="" alt="">  <li>Canvas</li> </a>
    <a href="https://www.fau.edu/successnetwork/">   <img src="" alt="">  <li>StarFish</li> </a>
    <a href="https://helpdesk.fau.edu/TDClient/2061/Portal/Home/">   <img src="" alt="">  <li>IT Support</li></a>
    <a href="https://library.fau.edu/">   <img src="" alt="">  <li>FAU Library</li></a>
    <a href="https://myfau.fau.edu/signed_in/selector/index">   <img src="" alt="">  <li>MyFau</li></a>
    <a href="https://www.fau.edu/career/">   <img src="" alt="">  <li>Career Center</li></a>
    </ul>
  </div>
</body>
</html>
