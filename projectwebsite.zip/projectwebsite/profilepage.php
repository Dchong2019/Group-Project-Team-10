<!DOCTYPE html>
<html>
<head>
  <title>Home</title>
<meta charset="UTF-8" name="" content="">
<link rel="stylesheet" href="styles3.css">
</head>
<body>
  <p1 id="profile_pic">Image</p1>
  <p2 id="name">Name</p2>
  <p3 id="fau_email">Email</p3>
  <p4 id="year">year</p4>
  <p5 id="Major">Major</p5>
  <p6 id="campus">Campus</p6>  
</body>
</html>
